sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("riskmanagementtwo.riskmananagementtwo.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);